#include "FEHLCD.h"
#include "FEHImages.h"
#include "FEHRandom.h"
#include "FEHUtility.h"
#include <math.h>
#include <string.h>
#include <algorithm>
using namespace std;


struct Position{
    float x; 
    float y;
};
struct Size{
    int width;
    int height;
};
enum spritePath{
    left1,
    left2,
    right1,
    right2
    
};




//Creates a class for a basic rectangular hitbox
class HitBox {
    public:
    //defines the hitbox's position and size
    Position position;
    Size size;
    //basic constructor which builds hitbox
    HitBox(int x, int y, int width, int height){
        position.x = x;
        position.y = y;
        size.width = width;
        size.height = height;
    }

    void updatePosition(int x, int y){
        position.x = x;
        position.y = y;
        //LCD.DrawRectangle(x,y,size.width, size.height);
    }
    //Checks if a xy coordinte is within the hitbox, if it is, return true, else, return false
    bool checkClick(int hitX, int hitY){
        if(hitX >= position.x && hitX <= position.x+size.width){
            if(hitY >= position.y && hitY <= position.y+size.height){
                return true;
            }
        }
        return false;
    } 
};




//Basic button with a border, text, and a hitbox
class Button {
    public:
    Position position;
    Size size;
    int id;
    //32 char-limit on text because I dont feel like implementing strings
    char text[33];
    //Initializes a basically nonexistent hitbox because C got mad at me for not including it. 
    HitBox hitbox = HitBox(0,0,0,0);
    

    //Constructor that assigns the position/size, as well as drawing the button
    Button(int x, int y, int width, int height, char text[], int id){
        position.x = x;
        position.y = y;
        size.width = width;
        size.height = height;
        this->id = id;
        hitbox = HitBox(x,y,width,height);

        strcpy(this->text, text);
        LCD.DrawRectangle(x,y,width,height);
        LCD.WriteAt(text,x,y);
        LCD.Update();
    }
    //Constructor that assigns the position/size. Made because we don't always want to draw a button right when it is made.
    Button(int x, int y, int width, int height, int id){
        position.x = x;
        position.y = y;
        size.width = width;
        size.height = height;
        this->id = id;
        hitbox = HitBox(x,y,width,height);
    }
    //Changes Button's text value to given value.
    void changeText(char change[33]){
        //fix bug where it draws on top of already existing text later
        strcpy(text, change);
    }
    //Draws the border/writes the text
    void drawButton(){
        LCD.DrawRectangle(position.x,position.y,size.width,size.height);
        LCD.WriteAt(text,position.x,position.y);
        LCD.Update();
    }

};





class Duck{
    public:
    Position position;
    Size size;
    HitBox hitbox = HitBox(0,0,0,0);
    
    FEHImage sprite;
    spritePath path; 

    Position* flightpath;
    bool dead;
    int direction, progress, speed, flapRate; //either 0 or 1, 0 for spawning on left side going right, 1 for spanwing on right side going left. 
    Duck(int x,int y,int width, int height, int speed){
        position.x = x;
        position.y = y;
        size.width = width;
        size.height = height;

        hitbox = HitBox(x - width/4,y - height/4,width,height);     
        flapRate = (int)(speed/10);   
        changeDirection();
        dead = false;
        progress = 0;

    }
    void generateRandomFlightPath(int n){
        //Include more randomization++using multiplier for harderness later
        Position startPosition;
        startPosition.x = 320*direction;
        startPosition.y = Random.RandInt() % (240-size.height);
        float coefficient = (Random.RandInt() % 3) / (float)(Random.RandInt() % 6 + 1);
        changeDirection();

        if(startPosition.y > 120){
            coefficient *= -1;
        }
        
        flightpath = (Position*)malloc(n*sizeof(Position));
        float xFactor = n/320.0, yFactor = (coefficient*n + startPosition.y)/240.0;
        if(coefficient*320 > 240){
            xFactor = n/(240/coefficient);
        }
        else if(coefficient*320+startPosition.y < 0){
            xFactor = (n/(-startPosition.y/coefficient));
        }
        if(direction){
            int counter = 0;
            for(int i = n; i > 0; i--){
                //printf("Check %d\n",i);
                flightpath[counter].x = i/xFactor; //creates n values that range from 320-0
                flightpath[counter].y = (coefficient*i + startPosition.y); //creates n y values that range from 0-24 
                counter++;  
            }

        }
        else{
            for(int i = 0; i < n; i++){
                //printf("Check %d\n",i);
                flightpath[i].x = i/xFactor; //creates n values that range from 0-320
                flightpath[i].y = (coefficient*i + startPosition.y); //creates n y values that range from 0-24   
            }
        }
        
        //printf("%f\n",coefficient);

    }
    void updatePosition(int x, int y){
        //printf("%d", progress);
        position.x = x;
        position.y = y;
        hitbox.updatePosition(x - size.width/4, y - size.height/4);
        if(progress % flapRate == 0){
            switch (path)
            {
            case 0: 
                path = left2;
                sprite.Open("PIC_files/duck3FEH.pic");
                break;
            case 1:
                path = left1;
                sprite.Open("PIC_files/duck1FEH.pic");
                break;
            case 2:
                path = right2;
                sprite.Open("PIC_files/duck4FEH.pic");
                break;
            case 3:
                path = right1;
                sprite.Open("PIC_files/duck2FEH.pic");
                break;
            }   
        }
        sprite.Draw(x,y);
        progress++;
    }
    void Kill(){
        free(flightpath);
        sprite.Close();
    }
    void increaseSpeed(){
        speed -= 10;
        flapRate = (int)(speed/10);
    }

    private: 
    void changeDirection(){
        direction = Random.RandInt() % 2;
        if(direction){
            path = left1;
            sprite.Open("PIC_files/duck1FEH.pic");
        }
        else{
            path = right1;
            sprite.Open("PIC_files/duck2FEH.pic");
        }
    }
};

void playMovie(char path[100]){
    FILE* textFile = fopen(path,"r");
    if(textFile == NULL){
        //printf("\nShits null");
    }
    FEHImage frame;
    char hold[100];
    
    while(fscanf(textFile, "%s", hold) != EOF){
        //printf("\n%s",hold);
        frame.Open(hold);
        frame.Draw(0,0);
        Sleep(0.1);
    }
    frame.Close();
    
}



Button* drawButtons(char loadFile[50]){
    //For ease of development/easier code, the menu buttons are loaded from a text file
    //This text file contains the buttons text, size, position, and ID
    //FILE pointer to Menu buttons load file
    FILE* loadButtons;

    //Since the amount of buttons can be dynamically altered from the text file, the size of the array that we store the 
    //button data in must be dynamically changeable. A pointer and allocation functions are used to accomplish this
    Button* buttons;
    loadButtons = fopen(loadFile, "r");
    
    //Allocates memory for single Button 
    buttons = (Button*)malloc(sizeof(Button));   
    //Counter used to determine how many Buttons are defined the file
    int count = 0;

    //Defines holding variables for the buttons, as they only get drawn when constructor is called
    //Find a better way to do this maybe?
    char name[33];
    int x,y,width,height, id;

    //The structure here for reading the file is a little wonky
    //I was running into issues with getting the correct data into the right variables
    //However, this works so I dont want to change it

    //Scans in the first Button's Name since the name gets scanned last in the structure
    fscanf(loadButtons, "%s", name);
    do{
        //If there is more than one button, reallocate enough memory for n amount of buttons
        //while retaining the data of the buttons already there
        if(count != 0){
            buttons = (Button*)realloc(buttons, (count+1)*sizeof(Button));
        }
        //gets width/height
        fscanf(loadButtons, "%d %d", &width, &height);
        //gets x/y positions
        fscanf(loadButtons, "%d %d" , &x, &y);
        //gets ID
        fscanf(loadButtons, "%d", &id);
        //Constructsthe button/draws the button on screen
        buttons[count] = Button(x,y,width,height,name,id);
        count++;
        //If another name exists, continue reading
    }while(fscanf(loadButtons, "%s", name) != EOF);

    return buttons;
}



void typeName(int score){
    LCD.Clear();
    
    float xMouse, yMouse;
    char name[9] = "";
    int counter = 0, position=130, scores[5];
    bool flag = false, clicked = false;
    
    Button* keyboard = drawButtons("load_files/Keyboard.txt");
    Button enterButton = Button(250,0,30,20, "Enter", 28);
    FILE* outputFile = fopen("load_files/Scores.txt", "a+");

    LCD.WriteLine("Enter your name: ");
    while(1){
        
        if(LCD.Touch(&xMouse,&yMouse)){
            for(int i = 0; i < 26; i++){
                if(keyboard[i].hitbox.checkClick(xMouse,yMouse) && !clicked){
                    clicked = true;
                    counter++;

                    LCD.SetFontColor(BLUE);
                    LCD.FillRectangle(0,80,320,50);
                    strcat(name, keyboard[i].text);
                    LCD.SetFontColor(BLACK);
                    LCD.WriteAt(name,130-(counter*2), 80);
                }
            }
            if(keyboard[26].hitbox.checkClick(xMouse, yMouse) && !clicked){
                printf("clicked");
                clicked = true;
                LCD.SetFontColor(BLUE);
                LCD.FillRectangle(0,80,320,50);
                name[counter-1] = NULL;
                counter--;
                LCD.SetFontColor(BLACK);
                LCD.WriteAt(name,130-(counter*2), 80);
            }
            if(enterButton.hitbox.checkClick(xMouse,yMouse)){
                //LCD.WriteAt(name, 130-(counter*5), 80);
                //Sleep(5.0);
                break;
            }
        }
        else{
            clicked = false;
        }
        
        // if(counter == 8){
        //     break;
        // }
        
        
    }
    fprintf(outputFile, "\n%s %d", name, score);
    fclose(outputFile);
    free(keyboard);


}


void gameLoop(){
    int n = 100, duckCount = 0, rounds = 0;
    float xMouse = 0.0, yMouse = 0.0;
    bool clicked = false;
    Duck duck = Duck(0,0,50,50, n);
    duck.generateRandomFlightPath(n);
    printf("\nGameLoop starting");
    LCD.SetFontColor(BLACK);
    
    FEHImage hunter;
    hunter.Open("PIC_files/hunter1FEH.pic");
    FEHImage grass;
    grass.Open("PIC_files/Grass1FEH.pic");
    FEHImage background;
    background.Open("PIC_files/Background3FEH.pic");
    FEHImage crosshair;
    crosshair.Open("PIC_files/CrosshairFEH.pic");

    
    while(1){
        if(duck.progress >= n){
            break;
        }

        LCD.Clear();
        background.Draw(0, 0);
        LCD.WriteAt(duckCount, 220, 10);
        //hunter.Draw(0,150);
        duck.updatePosition(duck.flightpath[duck.progress].x, duck.flightpath[duck.progress].y);
        crosshair.Draw(xMouse - 20, yMouse - 20);

        if(LCD.Touch(&xMouse,&yMouse)){
            //poor mans lazy evaluation or lazy lazy evaluation
            if(!clicked){
                LCD.SetFontColor(YELLOW);
                LCD.FillCircle(120, 135, 10);
                if(duck.hitbox.checkClick(xMouse, yMouse)){
                    LCD.Clear();
                    duck.progress = 0;
                    duckCount++;
                    duck.dead = true;
                    //duck.increaseSpeed();
                    duck.generateRandomFlightPath(n);
                }
            }
            clicked=true;
        }
        else{
            clicked=false;
            //duck.progress++;
            
        }
        //printf("\nCheck 1");
        LCD.Update();   
    }
    hunter.Close();
    grass.Close();
    duck.Kill();

    char badEnds[2][100] = {"PIC_files/Movies/gun/list.txt","PIC_files/Movies/dance/list.txt"};
    char goodEnds[2][100] = {"PIC_files/Movies/explosion/list.txt","PIC_files/Movies/dinnerdinner/list.txt"};
    int choice = Random.RandInt() % 2;
    if(duckCount > 19){
        playMovie(goodEnds[choice]);
    }
    else{
        playMovie(badEnds[choice]);
    }

    typeName(duckCount);
    
}






void mainMenu(){   
    //Clears screen and loads image of grass
    LCD.Clear();
    FEHImage background;
    background.Open("PIC_files/BackgroundFEH.pic");
    //grass.Open("PIC_files/Grass3FEH.pic");
    background.Draw(0,0);
    //grass.Draw(0,180);
    background.Close();
    //grass.Close();

    LCD.SetFontColor(BLACK);
    Button* buttons = drawButtons("load_files/MENU_buttons.txt");
    //variables for storing click position 
    float xMouse, yMouse;
    //Tracks whether a button has been clicked, and it it has, break out of loop and allow the main menu screen to be drawn again
    bool buttonClicked = false;
    //Constructs the button, but doesnt draw it. This is done because the exit button only needs to be drawn when a selection has been made
    //And constructing a new exit button for every selection would be messy 
    Button exitButton = Button(250,0,30,20,5);
    exitButton.changeText("Exit");

    
    while(1){
        //LCD.Update();
        //Checks if the lcd screen has been touched, and if it has, updates xMouse and yMouse with the position
        if(LCD.Touch(&xMouse,&yMouse)){
            //Checks if the "Start" button has been pressed and creates the screen for that
            if(buttons[1].hitbox.checkClick(xMouse, yMouse)){
                LCD.Clear();
                //While loop to make sure screen stay on until user clicks the exit button
                gameLoop();
                //typeName();
                break;
            }
            //Mostly same code as before but for the "Top Scores" button
            if(buttons[2].hitbox.checkClick(xMouse, yMouse)){
                //put a function here
                LCD.Clear();
                FILE* topScores = fopen("load_files/Scores.txt","r");
                char name[9];

                LCD.WriteLine("Top Scores:");
                //Load data from text file and store it to array here
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            //Handles "Instructions" button
            if(buttons[3].hitbox.checkClick(xMouse, yMouse)){
                //put a function here 
                LCD.Clear();
                LCD.WriteLine("Instructions:");
                LCD.WriteLine("Shoot the duck. If you miss, you lose. As you rack up points, the speed of the ducks will increase.");
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            //Handles "Credits" button
            if(buttons[4].hitbox.checkClick(xMouse, yMouse)){
                //put a function here 
                LCD.Clear();
                LCD.WriteLine("Credits:");
                LCD.WriteLine("Connor Jackson McGuffey");
                LCD.WriteLine("Cole Christopher Gibson");
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            
        }
        //Breaks out of main loop if exit button in not the main menu was pressed
        if(buttonClicked){
            break;
        }
        
    }
    //Frees allocated memory
    free(buttons);        
}

int main()
{
    //Main loop
    LCD.Clear(BLUE);
    while(1){
        LCD.Update();
        mainMenu();
    }
    
    //tempDisp();
    return 0;
}