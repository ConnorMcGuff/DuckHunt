#include "FEHLCD.h"
#include "FEHImages.h"
#include <string.h>
using namespace std;

//Creates a class for a basic rectangular hitbox
class HitBox {
    public:
    //defines the hitbox's position and size
    int x,y,width,height;
    //basic constructor which builds hitbox
    HitBox(int x, int y, int width, int height){
        this->x = x;
        this->y = y;
        this->width = width;
        this->height = height;
    }
    //Checks if a xy coordinte is within the hitbox, if it is, return true, else, return false
    bool checkClick(int hitX, int hitY){
        if(hitX >= x && hitX <= x+width){
            if(hitY >= y && hitY <= y+height){
                return true;
            }
        }
        return false;
    } 
};

//Basic button with a border, text, and a hitbox
class Button {
    public:
    int x,y,width,height, id;
    //32 char-limit on text because I dont feel like implementing strings
    char text[33];
    //Initializes a basically nonexistent hitbox because C got mad at me for not including it. 
    HitBox hitbox = HitBox(0,0,0,0);

    //Constructor that assigns the position/size, as well as drawing the button
    Button(int x, int y, int width, int height, char text[], int id){
        this->x = x;
        this->y = y;
        this->width = width;
        this->height = height;
        this->id = id;
        hitbox = HitBox(x,y,width,height);

        strcpy(this->text, text);
        LCD.DrawRectangle(x,y,width,height);
        LCD.WriteAt(text,x,y);
        LCD.Update();
    }
    //Constructor that assigns the position/size. Made because we don't always want to draw a button right when it is made.
    Button(int x, int y, int width, int height, int id){
        this->x = x;
        this->y = y;
        this->width = width;
        this->height = height;
        this->id = id;
        hitbox = HitBox(x,y,width,height);
    }
    //Changes Button's text value to given value.
    void changeText(char change[33]){
        //fix bug where it draws on top of already existing text later
        strcpy(text, change);
    }
    //Draws the border/writes the text
    void drawButton(){
        LCD.DrawRectangle(x,y,width,height);
        LCD.WriteAt(text,x,y);
        LCD.Update();
    }

};

void mainMenu(){   
    //Clears screen and loads image of grass
    LCD.Clear(BLUE);
    FEHImage background;
    background.Open("PIC_files/indexFEH.pic");
    background.Draw(0,160);
    background.Close();

    //For ease of development/easier code, the menu buttons are loaded from a text file
    //This text file contains the buttons text, size, position, and ID
    //FILE pointer to Menu buttons load file
    FILE* loadButtons;

    //Since the amount of buttons can be dynamically altered from the text file, the size of the array that we store the 
    //button data in must be dynamically changeable. A pointer and allocation functions are used to accomplish this
    Button* buttons;
    loadButtons = fopen("load_files/MENU_buttons.txt", "r");
    
    //Allocates memory for single Button 
    buttons = (Button*)malloc(sizeof(Button));   
    //Counter used to determine how many Buttons are defined the file
    int count = 0;

    //Defines holding variables for the buttons, as they only get drawn when constructor is called
    //Find a better way to do this maybe?
    char name[33];
    int x,y,width,height, id;

    //The structure here for reading the file is a little wonky
    //I was running into issues with getting the correct data into the right variables
    //However, this works so I dont want to change it

    //Scans in the first Button's Name since the name gets scanned last in the structure
    fscanf(loadButtons, "%s", name);
    do{
        //If there is more than one button, reallocate enough memory for n amount of buttons
        //while retaining the data of the buttons already there
        if(count != 0){
            buttons = (Button*)realloc(buttons, (count+1)*sizeof(Button));
        }
        //gets width/height
        fscanf(loadButtons, "%d %d", &width, &height);
        //gets x/y positions
        fscanf(loadButtons, "%d %d" , &x, &y);
        //gets ID
        fscanf(loadButtons, "%d", &id);
        //Constructsthe button/draws the button on screen
        buttons[count] = Button(x,y,width,height,name,id);
        count++;
        //If another name exists, continue reading
    }while(fscanf(loadButtons, "%s", name) != EOF);

    //variables for storing click position 
    float xMouse, yMouse;
    //Tracks whether a button has been clicked, and it it has, break out of loop and allow the main menu screen to be drawn again
    bool buttonClicked = false;
    //Constructs the button, but doesnt draw it. This is done because the exit button only needs to be drawn when a selection has been made
    //And constructing a new exit button for every selection would be messy 
    Button exitButton = Button(250,0,30,20,5);
    exitButton.changeText("Exit");
    while(1){
        //LCD.Update();
        //Checks if the lcd screen has been touched, and if it has, updates xMouse and yMouse with the position
        if(LCD.Touch(&xMouse,&yMouse)){
            //Checks if the "Start" button has been pressed and creates the screen for that
            if(buttons[1].hitbox.checkClick(xMouse, yMouse)){
                LCD.Clear();
                LCD.WriteLine("Game is being played");
                exitButton.drawButton();
                //While loop to make sure screen stay on until user clicks the exit button
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            //Sets button clicked to true so that the Main menu will be drawn again, and breaks out of current loop 
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            //Mostly same code as before but for the "Top Scores" button
            if(buttons[2].hitbox.checkClick(xMouse, yMouse)){
                //put a function here
                LCD.Clear();
                LCD.WriteLine("Top Scores:");
                //Load data from text file and store it to array here
                LCD.WriteLine("P. Holder    10000 Ducks");
                LCD.WriteLine("C. McGuff    3 Ducks");
                LCD.WriteLine("C. Gib       24 Ducks");
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            //Handles "Instructions" button
            if(buttons[3].hitbox.checkClick(xMouse, yMouse)){
                //put a function here 
                LCD.Clear();
                LCD.WriteLine("Instructions:");
                LCD.WriteLine("Shoot the duck. If you miss, you lose. As you rack up points, the speed of the ducks will increase.");
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            //Handles "Credits" button
            if(buttons[4].hitbox.checkClick(xMouse, yMouse)){
                //put a function here 
                LCD.Clear();
                LCD.WriteLine("Credits:");
                LCD.WriteLine("Connor Jackson McGuffey");
                LCD.WriteLine("Cole Christopher Gibson");
                exitButton.drawButton();
                while(1){
                    LCD.Update();
                    if(LCD.Touch(&xMouse,&yMouse)){
                        if(exitButton.hitbox.checkClick(xMouse, yMouse)){
                            buttonClicked = true;
                            break;
                        }
                    }
                }
            }
            
        }
        //Breaks out of main loop if exit button in not the main menu was pressed
        if(buttonClicked){
            break;
        }
        
    }
    //Frees allocated memory
    //SUPER SUPER IMPORTANT, WOULD cause a data leak if removed
    free(buttons);        
}

int main()
{
    //Main loop
    LCD.Clear(BLUE);
    while(1){
        LCD.Update();
        mainMenu();
    }
    
    //tempDisp();
    return 0;
}